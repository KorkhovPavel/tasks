import csv

import requests
import re

from bs4 import BeautifulSoup


def csv_wtite(data):
    with open('less_14.csv', 'a') as ff:
        names = ['title', 'reliased', 'reviews', 'tag']
        writer = csv.DictWriter(ff, fieldnames=names)
        writer.writerow(data)


def get_html(url):
    resp = requests.get(url)
    if not resp.ok:
        print(f'Code {resp.status_code} url : {url}')
    return resp.text


def get_games(html):
    soup = BeautifulSoup(html, 'lxml')
    pattern = r'^https://store.steampowered.com/app/'
    games = soup.find_all('a', href=re.compile(pattern))
    return games

def get_data(id):
    url = f'https://store.steampowered.com/apphoverpublic/{id}'
    html = get_html(url)
    soup = BeautifulSoup(html, 'lxml')
    try:
        title = soup.find('h4', class_="hover_title").text.strip()
    except:
        title = ''
    try:
        reliased = soup.find('div', class_="hover_release").text.split(':')[-1].strip()
    except:
        reliased = ''
    try:
        reviews_raw = soup.find('div', class_="hover_review_summary").text.strip()
    except:
        reviews = ''
    else:
        pattern = r'\d+'
        reviews = int(''.join(re.findall(pattern, reviews_raw)))
    try:
        tag_raw = soup.find_all('div', class_="app_tag")
    except:
        tag = ''
    else:
        tag_text = [tag.text for tag in tag_raw]
        tag = ','.join(tag_text)

    data_dict = {
        'title': title,
        'reliased': reliased,
        'reviews': reviews,
        'tag': tag
    }
    csv_wtite(data_dict)


def main():
    count = 0
    url = f'https://store.steampowered.com/search/results/?query&start={count}0&count=100&tags=1702'
    all_games = []
    while True:
        games = get_games(get_html(url))
        if games:
            all_games.extend(games)
            url = f'https://store.steampowered.com/search/results/?query&start={count}0&count=100&tags=1702'
            count += 100
        else:
            break
    for game in all_games:
        game_id = game.get('data-ds-appid')
        print(game_id)
        get_data(game_id)


if __name__ == '__main__':
    # https://store.steampowered.com/apphoverpublic/252490
    # data-ds-appid="1258080" a

    main()
