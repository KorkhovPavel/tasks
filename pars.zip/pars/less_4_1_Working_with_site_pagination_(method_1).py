import  requests
from  bs4 import BeautifulSoup
import csv

def get_html(url):
    resp = requests.get(url)
    if resp.ok:
        return resp.text
    print(resp.status_code)

def writer_csv(data):
    with open('less_4_1.csv', 'a') as file:
        writer=csv.writer(file)
        writer.writerow((data['name_csv'],
                         data['price'],
                         data['url_csv'],
                         data['sale_csv']))

def price_norm(price):
    price_good = price.replace('\n','')
    return price_good.replace(' ','')




def get_page_data(html):
    soup = BeautifulSoup(html,'lxml')
    diveic = soup.find_all('div',class_="subcategory-product-item__body")
    for div in diveic:
        name_csv = div.find('a',class_="link_gtm-js link_pageevents-js ddl_product_link").get('title')
        price = div.find('ins',class_="subcategory-product-item__price-num").text.strip()
        # price_csv = price_norm(price)
        url_csv = div.find('a', class_="link_gtm-js link_pageevents-js ddl_product_link").get('href')
        try:
            sale_csv = div.find('span', class_="label promo_label").text
        except:
            sale_csv=''
        data={
            'name_csv':name_csv,
            'price':price,
            'url_csv':url_csv,
            'sale_csv':sale_csv
        }
        writer_csv(data)






def main():
    for i in range(0,5):
        url = f'https:'
        all_html = get_html(url)
        get_page_data(all_html)

if __name__ == '__main__':
    main()