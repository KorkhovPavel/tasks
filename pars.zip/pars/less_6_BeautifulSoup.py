from bs4 import BeautifulSoup
import re

def get_salary(s):
    #salary: 2700 usd per month
    pattern = r'\d{1,9}'
    salary = re.findall(pattern,s)[0]
    # salary = re.search(pattern,s).group()
    print(salary)

def main():
    with open('index.html') as ff:
        soup = BeautifulSoup (ff,'lxml')
        row = soup.find_all('div',{"data-set":"salary"})

        #вывод с родителем .parent
        # alena = soup.find('div',text="Alena").parent
        # print(alena)

        # вывод до нужного пердка родителем .find_parent('div',class_="row")
        # alena = soup.find('div',text="Alena").find_parent('div',class_="row")
        # print(alena)

        salary = soup.find_all('div', {'data-set':"salary"})
        # print(salary)
        for i in salary:
            get_salary(i.text)



if __name__ == '__main__':
    main()