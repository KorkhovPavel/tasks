import  requests
from bs4 import  BeautifulSoup
import csv

def get_html(url):
    resp = requests.get(url)
    return resp.text

def refined_rating(val):
    rating_num=val.split(' ')[0]
    rating_num_result=rating_num.replace(',','')
    return rating_num_result

def write_csv(data):
    with open('less_2_plug.csv', 'a') as file:
        writers = csv.writer(file)
        writers.writerow((data['name'],
                          data['url_plug'],
                          data['rating']))




def get_data(html):
    soup = BeautifulSoup(html,'lxml')
    popular_pl = soup.find_all('section')[3]
    plugins = popular_pl.find_all('article')

    for plugin in plugins:
        name = plugin.find('h3').text
        url_plug = plugin.find('h3').find('a').get('href')
        rating = plugin.find('span',class_='rating-count').find('a').text
        rating_number = refined_rating(rating)
        dict_data = {
            'name':name,
            'url_plug':url_plug,
            'rating':rating_number
        }
        write_csv(dict_data)


    # return len(plugin)


def main():
    url = 'https://wordpress.org/plugins/'
    text_html=get_html(url)
    get_data(text_html)

if __name__ == '__main__':
    main()

