import csv

def write_csv(data):
    with open('less_5.csv','a') as file:
        writer = csv.writer(file)
        writer.writerow((data['name'],
                         data['surname'],
                         data['age']))

def write_csv_2(data):
    with open('less_5_csv_1.csv', 'a') as ff:
        order = ['name','surname','age']
        writer = csv.DictWriter(ff,order)
        writer.writerow(data)





def main():
    d1 = {'name':'Petr','surname':'Kaa','age':33}
    d2 = {'name': 'Anna', 'surname': 'Fii', 'age': 20}
    d3 = {'name': 'Val', 'surname': 'Dee', 'age': 55}
    data = [d1,d2,d3]
    # write
    for i in data:
        write_csv_2(i)

    # reader
    with open('less_5_csv_1.csv') as ff:
        heading = ['name', 'surname', 'age']
        reader = csv.DictReader(ff,heading)
        for r in reader:
            print(r)



if __name__ == '__main__':
    main()