import  requests
from bs4 import BeautifulSoup
import  csv

def get_html(url):
    resp=requests.get(url)
    return resp.text


def csv_write(data):
    with open('less_3_csv.csv', 'a') as file:
        writers = csv.writer(file)
        writers.writerow((data['name'],
                          data['tic_name'],
                          data['url'],
                          data['price_for_csv']))


def get_page_data(html):
    soup = BeautifulSoup(html,'lxml')
    table_trs = soup.find('table').find('tbody',class_="rc-table-tbody").find_all('tr')
    for k,tr in  enumerate(table_trs):
        try:
            tds = tr.find_all('td')
            name = tds[2].find('p').text
            tic_name = tds[2].find('div',class_="CoinItem__RankingArea-sc-1teo54s-2 edkTHK").find('p').text
            url = 'https://coinmarketcap.com' +  tds[2].find('a').get('href')
            price = tds[3].text
            price_for_csv = price.replace(',','')[1:]
            # print(f'{name} {tic_name} {url} {price_for_csv}')
            dict_data = {
                'name': name,
                'tic_name': tic_name,
                'url': url,
                'price_for_csv': price_for_csv
            }
            csv_write(dict_data)
        except Exception as exc:
            print(f'Ошибка - {exc} параметры {exc.args}')

def main():
    url='https://coinmarketcap.com/'
    all_html = get_html(url)
    get_page_data(all_html)

if __name__ == '__main__':
    main()