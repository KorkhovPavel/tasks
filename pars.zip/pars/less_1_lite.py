import requests
from bs4 import BeautifulSoup


def get_html(url):
    resp = requests.get(url)
    return resp.text

def get_date(html):
    soup=BeautifulSoup(html,'lxml')
    heading_1=soup.find('div',id="home-welcome").find('header').find('h1').text
    return heading_1

def main():
    url = 'https://wordpress.org/'
    res_txt = get_html(url)
    print(get_date(html=res_txt))

if __name__ == '__main__':
    main()
