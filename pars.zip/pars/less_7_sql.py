import csv

from peewee import *
db = PostgresqlDatabase(database='test', user='postgres',password='Gfdtk1986+',host='localhost' )

class Coin(Model):
    name = CharField()
    url = TextField()
    price = CharField()

    class Meta:
        database = db

def main():
    db.connect()
    db.create_tables([Coin])
    with open('less_4_2.csv') as ff:
        order = [ 'name','url','price']
        riders = csv.DictReader(ff,fieldnames=order)
        coins = list(riders)
        print(coins)
        #запись вариан 1 можно на прямую
        # for row in coins:
        #     print(row)
        #     coin = Coin(name=row['name'], url=row['url'],price=row['price'])
        #     print(coin)
        #     print(coin.save())
        # запись вариан 2 можно на прямую
        # with db.atomic():
        #     for row in coins:
        #         Coin.create(**row)
        # запись вариан 3 через csv
        with db.atomic():
            for row in range(0,len(coins),100):
                Coin.insert_many(coins[row:row+100]).execute()

if __name__ == '__main__':
    main()