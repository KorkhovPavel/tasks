import requests
import csv
from bs4 import BeautifulSoup
import random


# def csv_writer(data):
#     with open('less_12_csv.csv', 'a') as ff:
#         headers = []
#         writer = csv.DictWriter(ff, headers)
#         writer.writerow(data)


def get_proxy():
    url = 'https://free-proxy-list.net/'
    html = requests.get(url).text
    soup = BeautifulSoup(html, 'lxml')
    trs = soup.find('table', id="proxylisttable").find_all('tr')[1:11]
    proxies = []
    for tr in trs:
        tds = tr.find_all('td')
        ip = tds[0].text.strip()
        port = tds[1].text.strip()
        schema = 'https' if 'yes' in tds[6].text.strip() else 'http'
        dict_data = {
            'address': ip + ':' + port,
            'schema': schema
        }
        proxies.append(dict_data)
    return random.choice(proxies)


def get_html(url):
    p = get_proxy()
    proxy = {p['schema']: p['address']}
    resp = requests.get(url, proxies=proxy, timeout=5)
    return resp.json()["origin"]


def main():
    url = 'https://httpbin.org/ip'
    print(get_html(url))


if __name__ == '__main__':
    main()
